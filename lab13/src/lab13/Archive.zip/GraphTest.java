package lab13;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.LinkedList;


public class GraphTest {
	
	public static void main(String[] args) throws Throwable {
		BufferedReader input = new BufferedReader(new FileReader("/Users/educastro/Documents/programming/java/workspace/CS303/lab13/src/lab13/mediumGraph.txt"));
		Graph graph = new Graph(input);
		System.out.println(graph.tostring());
				
	}
}
