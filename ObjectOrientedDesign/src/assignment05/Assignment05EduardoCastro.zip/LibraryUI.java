package assignment05;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;

import javax.swing.*;

public class LibraryUI {

	final static int FIELD_WIDTH = 20;
	static Library library = new Library();

	public static void main(String[] args){

		// Declaration for the frame
		JFrame frame = new JFrame();

		// Declaration for the buttons
		JButton newStudentButton = new JButton("New Student");
		JButton seeStudentInfoButton = new JButton("See Student Information");
		
		// Defines what the newStudentButton will do if pressed
		newStudentButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				// Calls the method that will create a new JFrame
				newStudentPanel();
			}
		});
		
		// Defines what the seeStudentInfoButton will do if pressed
		seeStudentInfoButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				// Calls the method that will create a new JFrame
				seeStudentPanel();
			}
		});

		// Sets the Layout for this frame
		frame.setLayout(new FlowLayout());

		// Add the following components
		frame.add(newStudentButton);
		frame.add(seeStudentInfoButton);

		// Defines what the program should do if the close button is pressed
		frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		frame.pack();
		
		// Sets the frame to visible state
		frame.setVisible(true);
	}
	
	public static void seeStudentPanel() {
		// Declaration for the frame
		JFrame frame = new JFrame();
		
		// Declaration for the text area
		JTextArea studentInformationTextField = new JTextArea(20, 40);
		// Set the text for this component as the return from the listAllStudentsAsString. Basically shows a String.
		studentInformationTextField.setText(library.listAllStudentsAsString());
		
		// Declaration for the button
		JButton closeButton = new JButton("Close");
		
		// Defines the layout for the frame
		frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));

		// Add the components
		frame.add(new JLabel("Students:"));
		frame.add(studentInformationTextField);
		frame.add(closeButton);
		
		// Defines what the closeButton will do if pressed
		closeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				// Closes the frame but doesnt finish the program
				frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
			}
		});
		
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);		
	}
	
	
	public static void newStudentPanel() {
		// Declaration for the frame
		JFrame frame = new JFrame();
		
		// Declaration for the text fields
		JTextField uidTextField = new JTextField(FIELD_WIDTH);
		JTextField nameTextField = new JTextField(FIELD_WIDTH);
		JTextField emailTextField = new JTextField(FIELD_WIDTH);

		// Declaration for the buttons
		JButton okButton = new JButton("Save");
		JButton closeButton = new JButton("Close");
		
		// Sets the layout
		frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
		
		// Add an UID label and puts its textfield to the frame
		frame.add(new JLabel("UID:"));
		frame.add(uidTextField);
		
		// Add a email label and puts its textfield to the frame
		frame.add(new JLabel("Name:"));
		frame.add(nameTextField);
		
		// Add an email label and puts its textfield to the frame
		frame.add(new JLabel("Email:"));
		frame.add(emailTextField);
		
		// Adds buttons to the frame
		frame.add(okButton);
		frame.add(closeButton);

		// Defines what the okButton will do if pressed
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				// Collect data from the textfields and put it into variables
				String uid = uidTextField.getText();
				String name = nameTextField.getText();
				String email = emailTextField.getText();
				
				// create a student into the library with the previous variables as parameters 
				library.addStudent(uid, name, email);
				
				// erases the contents from all the textfields
				uidTextField.setText(null);
				emailTextField.setText(null);
				nameTextField.setText(null);
			}
		});
		
		// Defines what the closeButton will do if pressed
		closeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				// Closes the frame but doesnt finish the program
				frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
			}
		});
		
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);	
	}
}
