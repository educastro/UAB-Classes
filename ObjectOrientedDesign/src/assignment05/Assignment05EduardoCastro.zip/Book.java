package assignment05;

/**
 * Represents a book in the library.
 */
public class Book
{
  /**
   * Sets up a valid Book object .
   *
   * @param bookid unique library id for books
   * @param booktitle title of the book
   * @param bookauthor author of the book
   *
   * @precondition bookid != null && booktitle != null && bookauthor != null
   */
  public Book(String bookid, String booktitle, String bookauthor)
  {
    assert bookid != null && booktitle != null && bookauthor != null
           : "Precondition violation : invalid null data";

    id         = bookid;
    title      = booktitle;
    author     = bookauthor;
    loanRecord = null;
  }

  /**
   * returns unique book id.
   *
   * @return unique book id
   * @postcondition result != null
   */
  public String getId() { return id; }

  /**
   * returns book title.
   *
   * @return book title
   * @postcondition result != null
   */
  public String getTitle() { return title; }

  /**
   * returns book author.
   *
   * @return book author
   * @postcondition result != null
   */
  public String getAuthor()     { return author;     }

  /**
   * returns current loan record.
   *
   * @return current loan record (null, if the book is available).
   */
  public Loan getLoanRecord()
  {
    return loanRecord;
  }

  /**
   * sets current loan record.
   * @param checkoutRecord check out data
   * @precondition checkoutRecord != null
   */
  public void checkOutBook(Loan checkoutRecord)
  {
    assert loanRecord == null : "Precondition failed : Book already checked out";

    loanRecord = checkoutRecord;
  }

  /**
   * clears check out record.
   * @param loan checkout data for the book returned
   * @precondition @loan must be the same as the stored loan record
   */
  public void returnBook(Loan loan)
  {
    assert loanRecord == loan : "Precondition failed : Book not checked out";

    loanRecord = null;
  }

  /** unique id. */
  private String id;

  /** book title. */
  private String title;

  /** book author. */
  private String author;

  /** current loan record. */
  private Loan   loanRecord;
}
