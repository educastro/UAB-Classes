package lab14;

public class Vertex {
	String color;
	int pi;
	int d;
	
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getPi() {
		return pi;
	}
	public void setPi(int pi) {
		this.pi = pi;
	}
	public int getD() {
		return d;
	}
	public void setD(int d) {
		this.d = d;
	}
}