package lab12;

public class testGraph {

}
