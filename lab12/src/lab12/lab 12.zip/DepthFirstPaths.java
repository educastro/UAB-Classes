package lab12;

import java.util.LinkedList;
import java.util.Stack;


public class DepthFirstPaths {
	private boolean[] marked;    // marked[v] = is there an s-v path?
	private int[] edgeTo;        // edgeTo[v] = last edge on s-v path
	private final int s;         // source vertex
	LinkedList returnLinkedList = new LinkedList();


	/**
	 * Computes a path between <tt>s</tt> and every other vertex in graph <tt>G</tt>.
	 * @param G the graph you built in the previous assignment, make sure it has the adjacency list adj for each vertex
	 * @param s the source vertex
	 */
	public DepthFirstPaths(Graph G, int s) {
		//initialize marked, edgeTo and s
		this.s = s;
		edgeTo = new int[G.V];
		marked = new boolean[G.V];
		dfs(G, s);
	}

	// depth first search from v
	private void dfs(Graph G, int v) {
		//write your dfs code here. Edit edgeTo and marked whenever necessary. It would be easy to use recursion in this function
		marked[v] = true;
		for (int w : G.adj[v]) {
			if (!marked[w]) {
				edgeTo[w] = v;
				dfs(G, w);
			}
		}
	}

	/**
	 * Is there a path between the source vertex <tt>s</tt> and vertex <tt>v</tt>?
	 * @param v the vertex
	 * @return <tt>true</tt> if there is a path, <tt>false</tt> otherwise
	 */
	public boolean hasPathTo(int v) {
		//return something that represents the above task.
		return marked[v];
	}

	/**
	 * Returns a path between the source vertex <tt>s</tt> and vertex <tt>v</tt>, or
	 * <tt>null</tt> if no such path.
	 * @param v the vertex
	 * @return the sequence of vertices on a path between the source vertex
	 *   <tt>s</tt> and vertex <tt>v</tt>, as an Iterable
	 */
	public Iterable<Integer> pathTo(int v) {
		//implement your code
		if (!hasPathTo(v)) return null;
		Stack<Integer> path = new Stack<Integer>();
		for (int x = v; x != s; x = edgeTo[x])
			path.push(x);
		path.push(s);
		return path;
	}

	/**
	 * Unit tests the <tt>DepthFirstPaths</tt> data type.
	 */
	
	public void printPath(Graph undirectedGraph){
		String test = "";
		for (int v1 = 0; v1 < undirectedGraph.V; v1++) {
			if (hasPathTo(v1)) {
				System.out.print("0 to " + v1 + ": ");
				for (int x : pathTo(v1)) {
					if ((x == 0) && (x == v1)) 
						System.out.print(" " + x);
					else if (x == 0)
						System.out.print(", " + x);
					else if (x == v1)
						System.out.print(" " + x);
					else
						System.out.print(", " + x);
				}
				System.out.println();
			}

			else {
				System.out.printf("%d to %d (-):  not connected\n",undirectedGraph.V, v1);
			}

		}
	}

	public LinkedList topologicalSort(Graph G) throws Throwable{
		for (int v = 0; v < G.V; v++) {
            for (int w : G.adj[v]) {
            	DepthFirstPaths test = new DepthFirstPaths(G, w);
            	returnLinkedList.addFirst(w);
            	test.finalize();
            }
		}
		
		return returnLinkedList;
		
	}

}