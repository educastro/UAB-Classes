package lab08;

public class BinarySearchTree {
	
	public void insert(BinaryTree binaryTree, BinaryTreeNode newNode){
		BinaryTreeNode auxiliarNode = null;
		BinaryTreeNode currentNode = binaryTree.getRoot(); 
		
		while(currentNode != null){
			auxiliarNode = currentNode;
			if((int) newNode.getData() < (int) currentNode.getData()){
				currentNode = currentNode.getLeft();
			} else{
				currentNode = currentNode.getRight();
			}
		}
		
		newNode.setParent(binaryTree.getRoot());
		
		if(auxiliarNode == null){
			binaryTree.setRoot(newNode);
		} else if((int) newNode.getData() < (int) auxiliarNode.getData()){
			auxiliarNode.setLeft(newNode);
		} else{
			auxiliarNode.setRight(newNode);
		}						
	}
	
	public boolean search(BinaryTreeNode binaryTreeNode, int elementToBeFound){
		if((binaryTreeNode == null))
			return false; 
		if(elementToBeFound == (int) binaryTreeNode.getData()){
			return true;
		}
		
		if(elementToBeFound < (int) binaryTreeNode.getData()){
			return search(binaryTreeNode.getLeft(), elementToBeFound);
		} else{
			return search(binaryTreeNode.getRight(), elementToBeFound);
		}
	}
	
	public void indorderTreeWalk(BinaryTreeNode node){
		if(node != null){
			indorderTreeWalk(node.getLeft());
			System.out.println(node.getData().toString());
			indorderTreeWalk(node.getRight());
		}
	}
		
}
	
	


