package lab07;

public class SortLab {

	public void sort(int[] array){
		int sizeOfTheArray = array.length;
		int firstPosition = 0;
		int lastPosition = sizeOfTheArray - 1;

		while(sizeOfTheArray > 0){
			for(int i = firstPosition; i <= lastPosition; i++){
				if(array[firstPosition] > array[i])
					swap(array, firstPosition, i);
			}

			for(int j = lastPosition; j >= firstPosition; j--){
				if(array[lastPosition] < array[j])
					swap(array, lastPosition, j);
			}

			sizeOfTheArray = sizeOfTheArray - 2;
			firstPosition++;
			lastPosition--;
		}
	}

	public void swap(int[] array, int i, int j){
		int temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}
	
}
