package lab07;

public class SortLabTest {



	public static void main(String[] args) {
		int[] array = {5, 2, 6, 9, 10};
		SortLab sortLab = new SortLab();
		sortLab.sort(array);
	}
}
