package lab10;

public class HashMapTest {

	public static void main(String[] args) {

		HashMap hashTest = new HashMap();
		
		System.out.println("Inserting key 100");
		hashTest.put(100, "String key 100");
		System.out.println("Inserting key 1000");
		hashTest.put(1000, "String for key 1000");
		System.out.println("Inserting key 5");
		hashTest.put(5, "String key 5");
		
		System.out.println("------------------------------------------------------------");
		
		System.out.println("Result of getting key 100: " + hashTest.get(100));
		System.out.println("Result of getting key 1000: " + hashTest.get(1000));
		System.out.println("Result of getting key 5: " + hashTest.get(5));
		System.out.println("Result of getting key 10(that doesnt exist): " + hashTest.get(10));
		
		System.out.println("------------------------------------------------------------");
		
		System.out.println("Linear Probing for key 10000");
		hashTest.linearProbe(10000, "String for key 10000");
		System.out.println("Result from position 0 from array: " + hashTest.getValuePosition(0));
		System.out.println("Result from position 1 from array: " + hashTest.getValuePosition(1));
		System.out.println("Result from position 2 from array: " + hashTest.getValuePosition(2));	
	}

}
