package lab06;

public class LinkedListTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList linkedList = new LinkedList();
		linkedList.add(1);
		linkedList.add(2);
		linkedList.add(3);
		System.out.println("Size: " + linkedList.getSizeOfTheList());
		System.out.println(linkedList.getValue(1));
		System.out.println(linkedList.getValue(2));
		System.out.println(linkedList.getValue(3));
		System.out.println(linkedList.getValue(4));
		linkedList.add(10, 2);
		System.out.println("Size: " + linkedList.getSizeOfTheList());
		System.out.println(linkedList.getValue(1));
		System.out.println(linkedList.getValue(2));
		System.out.println(linkedList.getValue(3));
		System.out.println(linkedList.getValue(4));
		linkedList.removeElement(1);
		System.out.println("Size: " + linkedList.getSizeOfTheList());
		System.out.println(linkedList.getValue(1));
		System.out.println(linkedList.getValue(2));
		System.out.println(linkedList.getValue(3));
		System.out.println(linkedList.getValue(4));
	}

}
